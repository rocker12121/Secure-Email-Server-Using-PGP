<?php 
        require_once dirname(__FILE__) . '/PHPMailer.php';
        require_once dirname(__FILE__) . '/Exception.php';


  //PHPMailer Object
  if (isset($_POST['sendmail'])){
      
          
      $mail = new PHPMailer\PHPMailer\PHPMailer();
    
    
      //From email address and name
      $mail->From = "ehsanjadoon08@pgmail.com";
      $mail->FromName = "Ehsan Jadoon";
    
      //To address and name
       //$mail->addaddress("babaralleshah@gmail.com", "babar");*/
      $email= $_REQUEST['email'];
      $mail->addAddress($email);  //Recipient name is optional
    
      //Address to which recipient will reply
      $mail->addreplyto("ehsanjadoon08@gmail.com", "Reply");
    
      //CC and BCC
      //$mail->addcc("babaralleshah@gmail.com");
      //$mail->addbcc("babaralleshah@gmail.com");
    
      //Send HTML or Plain Text email
      $mail->isHTML(true);
    
      $subject= $_REQUEST['subject'];
      $mail->Subject = ($subject);
      
      $message= $_REQUEST['message'];
      $mail->Body = ($message);
      $mail->AltBody = "Message";
    
      if(!$mail->send()) 
      {
          return false;
      } 
      else 
      {
          echo"<script>window.location.replace(\"https://limpid-package.000webhostapp.com/compose1.php\");</script>";
      }


     /* $con= mysqli_connect("localhost", "id10054711_root", "123456", "id10054711_my_database");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }


    // Selecting a database 

    $db= mysqli_select_db($con, "my_database");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }
         
           $query="insert into outbox(recipient_id,subject,message) value('$email','$subject','$message')";

           

        if(mysqli_query($con,$query)){
        echo "<script>alert('your mail successfully send')
        window.location.replace(\"http://localhost/myproject/inbox1.php\");
        </script>";
        
       
        }

     */
  }
     ?>

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="compose1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose"></a>Compose</button><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
     <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>


     <div id="msg-box">
        <div id="msg-box-element">
           <form id="compose_form" name="compose_form" method="post" action="" >
          <ul>
          <li><label>&nbsp   To </label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="email" id="inputfield-to" required></li>

          <li><label>&nbsp    Subject </label>&nbsp<input type="text" name="subject" id="inputfield-subject"></li>
          <li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea id="textarea-body" name="message" rows="4" cols="50"> </textarea></li>
          <li><input type="submit" value="send" name="sendmail" id="btn-send">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input style="text-align: center" value="cancel" name="cancelmail" id="btn-cancel"></li>
          </ul>
          </form>  
  
    
        </div>
     </div>
 </div>

  
  
</body>
</html>


