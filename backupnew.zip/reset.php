<html>
<head>
    <title>reset page</title>
    <link rel="stylesheet" type="text/css" href="reset.css">   
</head>
    <body>

    	<style type="text/css">
            ::placeholder {color: white;opacity: 1}

        </style>

    	<img id="logo" src="logo2.png">    

    	<div class="reset-box">

<form>
<h2 align="center" style="color:#fff;">Reset password</h2>
<input type="password" name="username" placeholder="Old password" /><br /><br />
<input type="password" name="username" placeholder="New password" /><br /><br />
<input type="password" name="username" placeholder="Confirm new password" /><br /><br />
<input type="submit" value="Save" onclick="myFunction()"/><br /><br />
<a href="login.php" style="text-decoration:none;">Go back to Home page</a><br /><br />



</script>
</form>
</div>
    
    </body>
</html>