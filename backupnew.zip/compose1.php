<?php
    
    // Creating a database connection
    session_start();

    $con= mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }


    // Selecting a database 

    $db= mysqli_select_db($con, "id10693269_mydatabase");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }
    

    if(isset($_POST['submit'])){
        //echo "idr tk control aa rha hy";
     $senderemail=$_SESSION["email"];
     $receiveremail=$_POST['remail'];
     $subject=$_POST['subject'];
     $message=$_POST['message'];
     $digestrsa=sha1($message); //hash of a message is calculated and then rsa is applied
     
     //authentication start
     include_once 'rsakeypair.php';
    openssl_pkey_export($res, $privkey);
    //echo $privkey. "\n\n";
    
    $encryptedviaprivatekey = ""; //HOLDS text encrypted via private key of sender
    //$input= "My name is ehsan";
    openssl_private_encrypt($digestrsa, $encryptedviaprivatekey, $privkey);
    //echo $encryptedviaprivatekey;
    
    $pubkey=openssl_pkey_get_details($res);
$pubkey=$pubkey["key"];
//var_dump($privkey);
//var_dump($pubkey);
//echo $pubkey;
     
    $_SESSION['key'] = $pubkey;
    $_SESSION['encrypted'] = $encryptedviaprivatekey;
    $_SESSION['digest'] = $digestrsa;
    //authentication ends
    
     
       include_once 'aes_encryption.php';
     
    //  $data = json_encode(['first_name'=>'Dunsin','last_name'=>'Olubobokun','country'=>'Nigeria']);
        $inputKey= md5(microtime().rand());
        //echo $inputKey;
        $iv = "tuqZQhKP48e8Piuc";
        $blockSize = 256;
        $aes = new AESEncryption($message, $inputKey, $iv, $blockSize);
        $enc = $aes->encrypt();
        //echo $enc;
        $enc = $enc." ".$inputKey;
        //echo $enc;
        //$aes->setData($enc);
        //$dec=$aes->decrypt();
        //echo "After encryption: ".$enc."<br/>";
        //echo "After decryption: ".$dec."<br/>";
        //echo $enc;
     
     
     /*$cmd = "echo $message" .
        "--quiet --no-secmem-warning --encrypt --sign --armor ";
     $message = `$cmd`;
     mail($receiveremail,'Message from Web Form', $message_body,$subject);*/

        $query="insert into allmails(sender_email,receiver_email,subject,message) value('$senderemail','$receiveremail','$subject','$enc')";
        
        $server=strrchr($receiveremail,"@");
        
        if($server!="@pgmail.com")
        {
         
            
        require_once dirname(__FILE__) . '/PHPMailer.php';
        require_once dirname(__FILE__) . '/Exception.php';


  //PHPMailer Object
      
          
      $mail = new PHPMailer\PHPMailer\PHPMailer();
    
    
      //From email address and name
      $mail->From = ($senderemail);
      //$mail->FromName = "Ehsan Jadoon";
    
      //To address and name
       //$mail->addaddress("babaralleshah@gmail.com", "babar");*/
      //$email= $_REQUEST['email'];
      $mail->addAddress($receiveremail);  //Recipient name is optional
    
      //Address to which recipient will reply
      $mail->addreplyto("ehsanjadoon08@gmail.com", "Reply");
    
      //CC and BCC
      //$mail->addcc("babaralleshah@gmail.com");
      //$mail->addbcc("babaralleshah@gmail.com");
    
      //Send HTML or Plain Text email
      $mail->isHTML(true);
    
      $subject= $_REQUEST['subject'];
      $mail->Subject = ($subject);
      
      $message= $_REQUEST['message'];
      $mail->Body = ($message);
      $mail->AltBody = "Message";
    
      if(!$mail->send()) 
      {
          return false;
      } 
      else 
      {
          //echo"<script>window.location.replace(\"https://towable-echelons.000webhostapp.com/compose1.php\");</script//>;
          if(mysqli_query($con,$query)){
               echo "<script>alert('Message Sent Successfully')
               window.location.replace(\"inbox1.php\");
               </script>";
               }
      }
      /*if(mysqli_query($con,$query)){
               echo "<script>alert('Message Sent Successfully')
               window.location.replace(\"inbox1.php\");
               </script>";
               }*/


     /* $con= mysqli_connect("localhost", "id10054711_root", "123456", "id10054711_my_database");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }


    // Selecting a database 

    $db= mysqli_select_db($con, "my_database");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }
         
           $query="insert into outbox(recipient_id,subject,message) value('$email','$subject','$message')";

           

        if(mysqli_query($con,$query)){
        echo "<script>alert('your mail successfully send')
        window.location.replace(\"http://localhost/myproject/inbox1.php\");
        </script>";
        
       
        }

     */
 
         
         
            
        }
        else{
               if(mysqli_query($con,$query)){
               echo "<script>alert('Message Sent Successfully')
               window.location.replace(\"inbox1.php\");
               </script>";
               }
            }
}

?>
     
     
     
     

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="compose1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose"></a>Compose</button><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
     <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>


     <div id="msg-box">
        <div id="msg-box-element">
           <form id="compose_form" name="compose_form" method="post" action="" >
          <ul>
          <li><label>&nbsp   To </label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="remail" id="inputfield-to" required></li>

          <li><label>&nbsp    Subject </label>&nbsp<input type="text" name="subject" id="inputfield-subject"></li>
          <li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea id="textarea-body" name="message" rows="4" cols="50"> </textarea></li>
          <li><input type="submit" value="submit" name="submit" id="btn-send" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input style="text-align: center" value="cancel" name="cancelmail" id="btn-cancel"></li>
          </ul>
          </form>  
  
    
        </div>
     </div>
 </div>

  
  
</body>
</html>




