

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="compose1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose"></a>Compose</button><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
     <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>


     <div id="msg-box">
        <div id="msg-box-element">
          <ul>
          <li><label>&nbsp   To </label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="to" id="inputfield-to" required></li>

          <li><label>&nbsp    Subject </label>&nbsp<input type="text" name="subject" id="inputfield-subject"></li>
          <li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea id="textarea-body" rows="4" cols="50"> </textarea></li>
          <li><button id="btn-send">Send</button>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button id="btn-cancel">cancel</button></li>
          </ul>  
  
    
        </div>
     </div>
 </div>

  
</body>
</html>

<?php
    

    $con= mysqli_connect("localhost", "root", "", "my_database");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }



    $db= mysqli_select_db($con, "my_database");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }

    if(isset($_POST['submit'])){
     $firstName=$_POST['firstName'];
     $lastName=$_POST['lastName'];
     $password=$_POST['password'];
     $email=$_POST['email'];   

     $query="insert into registration_form(firstName,lastName,password,email) value('$firstName','$lastName','$password','$email')";

        if(mysqli_query($con,$query)){
        echo "<script>alert('you are successfully registered')
        window.location.replace(\"http://localhost/myproject/singup.php\");
        </script>";
       
        
        
        }
}

?>