
<?php
    
    // Creating a database connection

    $con= mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }


    // Selecting a database 

    $db= mysqli_select_db($con, "id10693269_mydatabase");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }

    if(isset($_POST['submit'])){
     $firstName=$_POST['firstName'];
     $lastName=$_POST['lastName'];
     $password=$_POST['password'];
     $email=$_POST['email'];   
     
     

        $query="insert into registration_form(firstName,lastName,password,email) value('$firstName','$lastName','$password','$email')";

        if(mysqli_query($con,$query)){
        echo "<script>alert('you are successfully registered')
        window.location.replace(\"login.php\");
        </script>";
       
        
        
        }
        
        include_once 'rsakeypair.php';

        openssl_pkey_export($res, $privkey);
            
        $pubkey=openssl_pkey_get_details($res);
        $pubkey=$pubkey["key"];
        
        $arr= str_split($pubkey, 64);
        $key_id= $arr[1];
        //echo $key_id;
        
        
}





?>
<html>
<head>
    <title>singup page</title>
    <link rel="stylesheet" type="text/css" href="singup.css">   
</head>
    <body>

        <style type="text/css">
            ::placeholder {color: white;}

        </style>
        <img src="logo2.png">

 <div class="signup-box">
        <h1 style="color: #fff;">Sign Up</h1>
    <form id="reg_form" name="reg_form" method="post" action="singup.php"  >
         <div >
        <input type="text" name="firstName" placeholder="First name" required>
        <div id="firstName_error"> </div>
        </div>

        <div>
        <input type="text" name="lastName" placeholder="Last name" required>
        <div id="lastName_error"> </div>
        </div>


        <div>
        <input id="password" name="password" type="password" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.              patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.confirmPassword.pattern =              this.value;"     placeholder="Password" required>
        <div id="password_error"> </div>
        </div> 

        <div>   
        <input id="confirmPassword" name="confirmPassword" type="password" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.              validity.patternMismatch ? 'Please enter the same Password as above' : '');" placeholder="Confirm password"                  required>        
        <div id="confirmPassword_error"> </div>
        </div>

        <div>  
        <input style="color:blue; border: none;border-bottom: 1px solid #fff;background: transparent;outline: none;height: 40px;color: #fff;
         font-size: 16px;" type="email" class="email" name="email"  placeholder="email" required>
        <div id="email_error"> </div>
        </div>

        <div>  
        <input type="submit" value="submit" name="submit" id="button" required>    
       </div>

        Already have account?<a href="login.php" style="text-decoration: none; font-family: 'Play', sans-serif; color: yellow;">&nbsp;Log In</a>
    </form>
    
 </div>

    </body>
</html>


<script type="text/javascript">

//getting all input text objects

  /*  var fname=document.forms["reg_form"]["firstName"];
    var lname=document.forms["reg_form"]["lastName"];
    var pass=document.forms["reg_form"]["password"];
    var confirm_pass=document.forms["reg_form"]["confirmPassword"];
    var email=document.forms["reg_form"]["email"];

//getting all error display objects

    var fname_error=document.getElementById("firstName_error");
    var lname_error=document.getElementById("lastName_error");
    var pass_error=document.getElementById("password_error");
    var confirm_pass_error=document.getElementById("confirmPassword_error");
    var email_error=document.getElementById("email_error");

    // SETTING ALL EVENT LISTENERS
    fname.addEventListener('blur', fnameVerify(), true);
    lname.addEventListener('blur', lnameVerify(), true);
    pass.addEventListener('blur', passVerify(), true);
    confirm_pass.addEventListener('blur', confirm_passVerify(), true);
    email.addEventListener('blur', emailVerify(), true);

    // validation function

function validate() {

  // validate username
  if (fname.value == "") {
    fname.style.border = "1px solid red";
    fname_error.textContent = "firstName is required";
    fname.focus();
    return false;
  }


   if (lname.value == "") {
    lname.style.border = "1px solid red";
    lname_error.textContent = "lastName is required";
    lname.focus();
    return false;
  }

    // validate password
  if (pass.value == "") {
    pass.style.border = "1px solid red";
    pass_error.textContent = "Password is required";
    pass.focus();
    return false;
  }

   // validate password
  if (pass.value.length < 3) {
    pass.style.border = "1px solid red";
    pass_error.textContent = "password must be at least 3 characters";
    pass.focus();
    return false;
  }

     // validate confirm password
  if (confirm_pass.value == "") {
    confirm_pass.style.border = "1px solid red";
    confirm_pass_error.textContent = "confirm Password is required";
    confirm_pass.focus();
    return false;
  }

  // check if the two passwords match
  if (pass.value != confirm_pass.value) {
    pass.style.border = "1px solid red";
    confirm_pass.style.border = "1px solid red";
    pass_error.innerHTML = "passwords not match";
    return false;
  }

 

  // validate email
  if (email.value == "") {
    email.style.border = "1px solid red";
    email_error.textContent = "Email is required";
    email.focus();
    return false;
  }
  
  
}
 

 function fnameVerify() {
  if (fname.value != "") {
   fname.style.border = "1px solid #fff";
   fname_error.innerHTML = "";
   return true;
  }
}

function lnameVerify() {
  if (lname.value != "") {
  fname.style.border = "1px solid #fff";
   lname_error.innerHTML = "";
   return true;
  }
}

function passVerify() {
  if (pass.value != "") {
    password.style.border = "1px solid #fff";
    pass_error.innerHTML = "";
    return true;
  }
  function confirm_passVerify() {
  if (pass.value === confirm_pass.value) {
    password.style.border = "1px solid #fff";
    confirm_pass.innerHTML = "";
    return true;
  }
}

function emailVerify() {
  if (email.value != "") {
    email.style.border = "1px solid #fff";
    email_error.innerHTML = "";
    return true;
  }
}*/

</script>



