<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="decryption1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose"></a>Compose</button><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
     <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>


 </div>

  
  
</body>
</html>