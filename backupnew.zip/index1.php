<!DOCTYPE html>
<html>
<head>
	<title>Send mail from PHP using SMTP</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">
<h1 class="text-center">Sending Emails in PHP from localhost with SMTP</h1>
<h2 class="text-center">Part 3: Using PHPMailer with attachments</h2>
<hr>
	
	<div class="row">
    <div class="col-md-9 col-md-offset-2">
        <form role="form" method="post" enctype="multipart/form-data">
        	<div class="row">
                <div class="col-sm-9 form-group">
                    <label for="email">To Email:</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" maxlength="50">
                </div>
            </div>

            <div class="row">
                <div class="col-sm-9 form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" class="form-control" id="subject" name="subject" value="Test Mail with attachments" maxlength="50">
                </div>
            </div>
            
            <div class="row">
                <div class="col-sm-9 form-group">
                    <label for="name">Message:</label>
                    <textarea class="form-control" type="textarea" id="message" name="message" placeholder="Your Message Here" maxlength="6000" rows="4">Test mail using PHPMailer</textarea>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-9 form-group">
                    <label for="name">File:</label>
                    <input name="file[]" multiple="multiple" class="form-control" type="file" id="file">
                </div>
            </div>
             <div class="row">
                <div class="col-sm-9 form-group">
                    <button type="submit" name="sendmail" class="btn btn-lg btn-success btn-block">Send</button>
                </div>
            </div>
        </form>
	</div>
</div>
<?php 
        require_once 'PHPMailer.php';
        require_once 'Exception.php';


  //PHPMailer Object
  $mail = new PHPMailer\PHPMailer\PHPMailer();


  //From email address and name
  $mail->From = "ehsanjadoon08@gmail.com";
  $mail->FromName = "Ehsan Jadoon";

  //To address and name
  // $mail->addaddress("babaralleshah@gmail.com", "babar");
  //$email->$_POST['email'];
  $email = "alisbec340@gmail.com";
  $mail->addAddress($email);  //Recipient name is optional

  //Address to which recipient will reply
  $mail->addreplyto("ehsanjadoon08@gmail.com", "Reply");

  //CC and BCC
  // $mail->addcc("babaralleshah@gmail.com");
  // $mail->addbcc("babaralleshah@gmail.com");

  //Send HTML or Plain Text email
  $mail->isHTML(true);

  $mail->Subject = "A Message From Spotter";
  $mail->Body = "<i>This will be the message from spotter</i>";
  $mail->AltBody = "Spotter Message";

  if(!$mail->send()) 
  {
      return false;
  } 
  else 
  {
      return true;
  }
     ?>
</body>
</html>