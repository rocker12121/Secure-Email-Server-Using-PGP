<?php
    
    // Creating a database connection
    session_start();

    $con= mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }


    // Selecting a database 

    $db= mysqli_select_db($con, "id10693269_mydatabase");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }
    

    if(isset($_POST['submit'])){
        echo "idr tk control aa rha hy";
     $senderemail=$_SESSION["email"];
     $receiveremail=$_POST['remail'];
     $subject=$_POST['subject'];
     $message=$_POST['message'];   
     
     
    $text = "Peter Piper picked a peck of pickled peppers";
    $RSA = new RSA_Handler();
    $keys = $RSA->generate_keypair(1024);
    $encrypted = $RSA->encrypt($text, $keys[0]);
    $decrypted = $RSA->decrypt($encrypted, $keys[1]);
    echo $decrypted; //Will print Peter Piper picked a peck of pickled peppers

     

        $query="insert into allmails(sender_email,receiver_email,subject,message) value('$senderemail','$receiveremail','$subject','$message')";

        if(mysqli_query($con,$query)){
        echo "<script>alert('Message Sent Successfully')
        window.location.replace(\"inbox1.php\");
        </script>";
       
        
        
        }
}

?>
     
     
     
     

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="compose1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose"></a>Compose</button><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
     <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>


     <div id="msg-box">
        <div id="msg-box-element">
           <form id="compose_form" name="compose_form" method="post" action="" >
          <ul>
          <li><label>&nbsp   To </label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="remail" id="inputfield-to" required></li>

          <li><label>&nbsp    Subject </label>&nbsp<input type="text" name="subject" id="inputfield-subject"></li>
          <li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea id="textarea-body" name="message" rows="4" cols="50"> </textarea></li>
          <li><input type="submit" value="submit" name="submit" id="btn-send" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input style="text-align: center" value="cancel" name="cancelmail" id="btn-cancel"></li>
          </ul>
          </form>  
  
    
        </div>
     </div>
 </div>

  
  
</body>
</html>




