

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="drafts1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose">Compose</button></a><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
      <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>

     <div id="display-msg-div" style="overflow:scroll ; display:none;">
      <p id="date1"></p>
      <p id="username1"></p>
      <p id="subject1"></p>
      <p id="msg1"></p>

     </div>

     <div id="table-div" style="overflow:scroll ; display:block">
        <table id="mytable">
         
          <?php
     $conn = mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  $sql = "SELECT recipient_id, subject,  message FROM draft";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["recipient_id"]. "</td><td>" . $row["subject"] . "</td><td>" . $row["message"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


        </table>

        
                      <br>

<button onclick="myFunction()">Try it</button>

  <script type="text/javascript">
    function displayMail(u , s , me){
      document.getElementById("table-div").style.display="none"; 
      document.getElementById("display-msg-div").style.display="block";
        n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();
        document.getElementById("date1").innerHTML = m + "/" + d + "/" + y;
        document.getElementById("username1").innerHTML = u;
        document.getElementById("subject1").innerHTML = s;
        document.getElementById("msg1").innerHTML = me;  
      }
      </script>

<script>
function myFunction() {
  var table = document.getElementById("mytable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);

  cell1.innerHTML = "saif2109";
  cell2.innerHTML = "important document";
  cell3.innerHTML = "Pretty Good Privacy (PGP) is an encryption program that provides cryptographic privacy and authentication for data communication. PGP is used for signing, encrypting, and decrypting texts, e-mails, files, directories, and whole disk partitions and to increase the security of e-mail communications.";
  addRowHandlers();
}




function addRowHandlers() {
    var table = document.getElementById("mytable");
    var rows = table.getElementsByTagName("tr");
    for (i = 0; i < rows.length; i++) {
        var currentRow = table.rows[i];
        var createClickHandler = 
            function(row) 
            {
                return function() { 
                                        var username = (row.getElementsByTagName("td")[0]).innerHTML;
                                        var subject = (row.getElementsByTagName("td")[1]).innerHTML;
                                        var msg = (row.getElementsByTagName("td")[2]).innerHTML;
                                        displayMail(username , subject , msg );
                                        //document.getElementById("mytable").innerHTML=document.getElementById("indiviual-msg-div").innerHTML;
                                        //alert(" user name: " + username +" subject: "+subject+" message: "+msg);
                                 };
            };

        currentRow.onclick = createClickHandler(currentRow);
    }
}
addRowHandlers();


</script>

     </div>
 </div>

  

  
</body>
</html>


