<?php
session_start();

// Creating a database connection
$con= mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
?>

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="inbox1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose">Compose</button></a><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
      <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="https://towable-echelons.000webhostapp.com/outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>

     <div id="display-msg-div" style="overflow:scroll ; display:none;">
      <p id="date1"></p>
      <p id="username1"></p>
      <p id="subject1"></p>
      <p id="msg1"></p>

     </div>

     <div id="table-div" style="overflow:scroll ; display:block">
        
                <table id="mytable">
         <?php 
                //receiving sessions from compose page
                $encryptedviaprivatekey = $_SESSION['encrypted'];
                $pubkey = $_SESSION['key'];
                $digestrsa= $_SESSION['digest'];
                //echo $encryptedviaprivatekey;
                openssl_public_decrypt($encryptedviaprivatekey,$decrypted,$pubkey);
                //echo $decrypted;
         
                //if($digestrsa == $decrypted){
         
                $mail= $_SESSION["email"];
                //echo $mail;
                $sql="select sender_email, subject,  message from allmails where receiver_email='$mail'";
               $result = $con->query($sql);
                 if ($result->num_rows > 0) {
    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $message= $row["message"];
                        $msgarray = explode(" ", $message);  //explode function splits on the basis of space
                        include_once 'aes_encryption.php';
                        $iv = "tuqZQhKP48e8Piuc";
                        $blockSize = 256;
                        $aes = new AESEncryption($msgarray[0], $msgarray[1], $iv, $blockSize);
                        $dec=$aes->decrypt();
                        $digest=sha1($dec);
                        if($digestrsa=$digest){
                     echo "<tr><td>" . $row["sender_email"]. "</td><td>" . $row["subject"] . "</td><td>" . $dec . "</td></tr>";
                        }
                    }
                   echo "</table>";
                 } else { echo "0 results"; }
                 $con->close();
                //}
                   ?>
                   
                    </table>
                
                  <br>

<button onclick="myFunction()">Try it</button>

  <script type="text/javascript">
    function displayMail(u , s , me){
      document.getElementById("table-div").style.display="none"; 
      document.getElementById("display-msg-div").style.display="block";
        n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();
        document.getElementById("date1").innerHTML = m + "/" + d + "/" + y;
        document.getElementById("username1").innerHTML = u;
        document.getElementById("subject1").innerHTML = s;
        document.getElementById("msg1").innerHTML = me;  
      }
      </script>

<script>
function myFunction() {
  var table = document.getElementById("mytable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  cell1.innerHTML = "saif2109";
  cell2.innerHTML = "important document";
  cell3.innerHTML = "Pretty Good Privacy (PGP) is an encryption program that provides cryptographic privacy and authentication for data communication. PGP is used for signing, encrypting, and decrypting texts, e-mails, files, directories, and whole disk partitions and to increase the security of e-mail communications.";
  addRowHandlers();
}




function addRowHandlers() {
    var table = document.getElementById("mytable");
    var rows = table.getElementsByTagName("tr");
    for (i = 0; i < rows.length; i++) {
        var currentRow = table.rows[i];
        var createClickHandler = 
            function(row) 
            {
                return function() { 
                                        var username = (row.getElementsByTagName("td")[0]).innerHTML;
                                        var subject = (row.getElementsByTagName("td")[1]).innerHTML;
                                        var msg = (row.getElementsByTagName("td")[2]).innerHTML;
                                        displayMail(username , subject , msg );
                                        //document.getElementById("mytable").innerHTML=document.getElementById("indiviual-msg-div").innerHTML;
                                        //alert(" user name: " + username +" subject: "+subject+" message: "+msg);
                                 };
            };

        currentRow.onclick = createClickHandler(currentRow);
    }
}
addRowHandlers();


</script>

     </div>
 </div>

  

  
</body>
</html>


