

<html>
<head>
  <title>Responsive Side Menu</title>
  <link rel="stylesheet" href="drafts1.css">
</head>
<body>

  <img id="logo" src="logo2.png">
  <a href="compose1.php"><button id="btn-compose">Compose</button></a><br><br><br>
 
  <div id="main-div">
     <div id="side-nav">
      <ul>
      <li><a href="inbox1.php" id="btn-inbox">Inbox</a></li>
      <li><a href="outbox1.php" id="btn-outbox">Outbox</a></li>
      <li><a href="drafts1.php" id="btn-draft">Drafts</a></li>
      <li><a href="encryption1.php" id="btn-encrypt">Encryption</a></li>
      <li><a href="decryption1.php" id="btn-decrypt">Decryption</a></li>
      <li><a href="key-managment1.php" id="btn-key-management">Key Management</a></li>
      </ul>
     </div>

     <div id="display-msg-div" style="overflow:scroll ; display:none;">
      

     </div>

     <div id="table-div" style="overflow:scroll ; display:block">
        <table id="mytable">
         
          <?php
     $conn = mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  $sql = "SELECT recipient_id, subject,  message FROM draft";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
    //echo "<tr><td>" . $row["recipient_id"]. "</td><td>" . $row["subject"] . "</td><td>" . $row["message"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


        </table>

        
                      <br>

Public Key: 

     </div>
 </div>

  

  
</body>
</html>


