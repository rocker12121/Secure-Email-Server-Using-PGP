<?php
session_start();
?>

<?php
// Get public key
//include_once 'rsakeypair.php';
//$pubkey=openssl_pkey_get_details($res);
//$pubkey=$pubkey["key"];
//var_dump($privkey);
//var_dump($pubkey);
//echo $pubkey;


$encryptedviaprivatekey = $_SESSION['encrypted'];
$pubkey = $_SESSION['key'];
//echo $encryptedviaprivatekey;
openssl_public_decrypt($encryptedviaprivatekey,$decrypted,$pubkey);
echo $decrypted;
?>