<?php

    $res = openssl_pkey_new();

?>