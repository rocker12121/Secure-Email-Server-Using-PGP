<?php
// Start the session
session_start();
?>

<html>
    <form name="submit" method="post" action="" >
    <input type="submit" name="submit" value="submit">
</form>
</html>


<?php
// Get private key
    include_once 'rsakeypair.php';
    openssl_pkey_export($res, $privkey);
    //echo $privkey. "\n\n";
    
    $encryptedviaprivatekey = ""; //HOLDS text encrypted via private key of sender
    $input= "My name is ehsan";
    openssl_private_encrypt($input, $encryptedviaprivatekey, $privkey);
    echo $encryptedviaprivatekey;
    
    $pubkey=openssl_pkey_get_details($res);
$pubkey=$pubkey["key"];
//var_dump($privkey);
//var_dump($pubkey);
//echo $pubkey;
     
    $_SESSION['key'] = $pubkey;
    $_SESSION['encrypted'] = $encryptedviaprivatekey;
    if(isset($_POST['submit'])){
      $URL="https://towable-echelons.000webhostapp.com/rsapub.php";
            echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";   
    }
?>
