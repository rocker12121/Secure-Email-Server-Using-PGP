<?php
// Start the session
session_start();
?>

<html>
<head>
    <title>Login page</title>
    <link rel="stylesheet" type="text/css" href="login.css">   
</head>
    <body class="my-container">

        <style type="text/css">
            ::placeholder {color: white;opacity: 0.6}

        </style>

    	<img src="logo2.png">
    <div class="login-box" style="opacity: 0.7">
    <img src="avatar.png" class="avatar">
        <h1>Login Here</h1>
            <form id="login_form" name="login_form" method="post" action="" >
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Username" required>
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password" required>
            <input type="submit" name="submit" value="Login">
            
    		<a href="reset.php" style=" text-align: center; font-size:13px; font-family:Tahoma, Geneva, sans-serif;">Reset password?</a>
  
    		<br /><br /><br /><br />
    		Don't have account?<a href="http://localhost/myproject/singup.php" style="font-family:'Play', sans-serif;">&nbsp;Sign Up</a>    
            </form>
        
        
        </div>

        <div class="description" style="opacity: 0.7">
        	<p style="font-size:20px;" >Pretty Good Privacy (PGP) is an encryption program that provides cryptographic privacy and authentication for data communication. PGP is used for signing, encrypting, and decrypting texts, e-mails, files, directories, and whole disk partitions and to increase the security of e-mail communications.</p>
        	
        </div>
    
    </body>
</html>
<?php
    // Creating a database connection
    $con= mysqli_connect("localhost", "id10693269_ehsan", "ehsan", "id10693269_mydatabase");
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    // Selecting a database 
    $db= mysqli_select_db($con, "id10693269_mydatabase");
    if (!$db) {
        die("Database selection failed: " . mysqli_connect_error());
    }
    if(isset($_POST['submit'])){
        //receiving session from compose page
        $encryptedviaprivatekey = $_SESSION['encrypted'];
        $pubkey = $_SESSION['key'];
        $digestrsa= $_SESSION['digest'];
        
        //sending session to inbox page
        $_SESSION['key'] = $pubkey;
        $_SESSION['encrypted'] = $encryptedviaprivatekey;
        $_SESSION['digest'] = $digestrsa;
        
        $username=$_POST['username'];
        $password=$_POST['password'];
        $query="select * from registration_form where email = '$username' and password = '$password' ";
        $result=mysqli_query($con,$query);
        $a=mysqli_num_rows($result);
        if($a==1){
            $URL="https://towable-echelons.000webhostapp.com/inbox1.php";
            echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
            echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
            $_SESSION["email"] = $username; //username is email
        }
        else{
        	echo "<script>alert('you have entered incorrect password')
        	window.location.replace(\"https://towable-echelons.000webhostapp.com/login.php\");
            </script>";
        }
    }
?>